hi ompaViLage here,if you dint get it alr.
Lemme say something this will not give Vbucks its a troll app.But dont click Give Vbucks!!
and agree to all the warnings if you dont know what your doing!
also put the .png file and .ico in C drive

I am not responsible for any damage
if you know what your doing run it in desktop 
PEACE -- OmpaViLage