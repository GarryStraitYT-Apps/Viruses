# Worm-Locker2.0
Please. Do not run this file on your or another computer !!! Use this file for educational purposes only !!! I am not responsible for the damage caused. THE FILE IS INFECTED BY RANSOMWARE !!!
