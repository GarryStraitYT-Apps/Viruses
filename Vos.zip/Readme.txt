I am not responsible for any damages.
This is made in batch and will destroy your computer on 5th november i am not responsible for any damage!